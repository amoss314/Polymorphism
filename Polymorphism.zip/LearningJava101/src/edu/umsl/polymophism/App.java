package edu.umsl.polymophism;

public class App {

	public static void main(String[] args) {
		
		Car c = new CivicSport();
		System.out.println("Civic Sport");
		System.out.println("Number of Tires: " +c.getNumberOfTires());
		System.out.println("Max Speed: " +c.getMaxSpeed());
		System.out.println("Number of Doors: " +c.getNumberOfDoors());
		System.out.println("Number of Lights: " +c.getNumberOfLights());
		System.out.println("GPS? " +c.equals(true));
		
		
	}

}
