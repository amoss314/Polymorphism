package edu.umsl.polymophism;

public interface Car {
	
	public int getNumberOfTires();
	
	public int getMaxSpeed();
	
	public int getNumberOfDoors();
	
	public int getNumberOfLights();
	
	

}
