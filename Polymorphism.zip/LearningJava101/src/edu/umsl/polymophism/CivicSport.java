package edu.umsl.polymophism;


public class CivicSport extends Honda {

@Override
	public int getNumberOfTires(){
	
		return super.getNumberOfTires();
}

@Override
	public int getMaxSpeed(){
	
	return super.getMaxSpeed();
	
}

@Override
	public int getNumberOfDoors(){
	
	return 2;
	
}

@Override
	public int getNumberOfLights(){
	
	return 8;
		
}

	public boolean hasGPS(){
		
		return true;
		
	}

}
