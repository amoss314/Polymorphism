package edu.umsl.polymophism;

public class Honda implements Car {

	public int getNumberOfTires() {
		
		return 4;
	}

	public int getMaxSpeed() {
		
		return 95;
	}

	public int getNumberOfDoors() {
		
		return 4;
	}

	public int getNumberOfLights() {
		
		return 8;
	}

	

}
